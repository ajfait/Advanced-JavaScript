// Create global variable
let labTitle = "Programming for Designers - Lab 2";

// Log to the console
const init = () => {
  let id = 10;
  let firstName = "Alison";
  let bornInMadison = false;

  console.log(id, firstName, bornInMadison);

  printLabTitle();
};

// Log to the console
const printLabTitle = () => console.log(labTitle);
